#!/bin/bash
set -e

LOG_DIR="logs"
BACKUP_DIR="backup"
ENCRYPTED_DIR="encrypted"
ENCRYPTED_LOGS="$ENCRYPTED_DIR/logs"
ENCRYPTED_BACKUP="$ENCRYPTED_DIR/backup"

mkdir -p "$ENCRYPTED_LOGS" "$ENCRYPTED_BACKUP"

read -s -p "Digite a senha para criptografia: " PASSWORD
echo ""

encrypt_file() {
    local input="$1"
    local output="$2"
    echo "[+] Criptografando: $input"
    openssl enc -aes-256-cbc -salt -in "$input" -out "$output" -k "$PASSWORD"
}

for file in "$LOG_DIR"/*; do
    [[ -f "$file" ]] && encrypt_file "$file" "$ENCRYPTED_LOGS/$(basename "$file").enc"
done

for file in "$BACKUP_DIR"/*; do
    [[ -f "$file" ]] && encrypt_file "$file" "$ENCRYPTED_BACKUP/$(basename "$file").enc"
done

echo "[✔] Criptografia concluída. Arquivos salvos em '$ENCRYPTED_DIR/'"
