#!/bin/bash
echo "[INFO] Executando suíte terminal-master..."
bash "$(dirname "$0")/healthcheck.sh"

