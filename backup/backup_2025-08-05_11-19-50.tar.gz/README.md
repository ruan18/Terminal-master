# Terminal-master
Scripts práticos de automação, segurança e hacking ético via terminal Linux.
